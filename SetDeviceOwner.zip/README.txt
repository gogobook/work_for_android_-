This project is derived from the AndroidBeamDemo in the Android SDK.
